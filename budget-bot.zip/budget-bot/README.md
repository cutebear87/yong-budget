# 💰 Family Budget Bot — Setup Guide

## Step 1 — Create your Telegram Bot (2 min)

1. Open Telegram and search for **@BotFather**
2. Send `/newbot`
3. Give it a name: `Our Budget`
4. Give it a username: `ourbudget2026_bot` (must be unique, end in _bot)
5. BotFather will send you a token like: `7123456789:AAFxxxxxxxxxxxxxxxxxxxxxx`
6. **Save that token — you'll need it in Step 3**

---

## Step 2 — Create a group chat (1 min)

1. Create a new Telegram group
2. Name it something like "💰 Our Budget"
3. Add your wife
4. Add your bot (search for the username you chose)

---

## Step 3 — Deploy to Railway (5 min, free)

1. Go to **railway.app** and sign up (free, use GitHub login)
2. Click **"New Project" → "Deploy from GitHub repo"**
3. Upload or connect this folder as a GitHub repo
   - Easiest: go to **github.com**, create a new repo, upload these 3 files:
     `bot.py`, `requirements.txt`, `railway.toml`
4. In Railway, go to your project → **Variables** tab
5. Add a variable: `BOT_TOKEN` = your token from Step 1
6. Railway will auto-deploy. You'll see "🤖 Budget bot is running!" in the logs.

---

## Step 4 — Start using it!

In your group chat, type `/start` to see all commands.

### Commands cheat sheet:
| Command | What it does |
|---|---|
| `/add 64 dining dinner at nobu` | Log an expense |
| `/add 187 groceries trader joes` | Log groceries |
| `/income 5000 paycheck` | Log income |
| `/summary` | Monthly overview |
| `/spent` | Category breakdown with budget bars |
| `/recent` | Last 10 transactions |
| `/budget groceries 400` | Set a monthly budget limit |
| `/budgets` | See all budget limits |
| `/delete` | Delete a transaction |
| `/month 2026-02` | View a past month |

### Category shortcuts (you can abbreviate):
- `housing` → Housing/Rent
- `grocery` or `grocer` → Groceries
- `dining` or `din` → Dining Out
- `sub` → Subscriptions
- `transport` or `trans` → Transportation
- `util` → Utilities
- `entertain` or `ent` → Entertainment
- `saving` → Savings
- `personal` or `shop` → Personal/Shopping

---

## Notes
- Both you and your wife can add transactions from the shared group
- Every transaction shows who added it
- Data is stored permanently on Railway's server
- Free Railway tier is plenty for personal use
